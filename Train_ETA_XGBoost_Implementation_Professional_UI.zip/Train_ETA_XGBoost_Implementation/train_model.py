"""Train and evaluate an XGBoost regression model for delay prediction."""
from pathlib import Path
import json
import joblib
import pandas as pd
import matplotlib.pyplot as plt

from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "dataset" / "train_data.csv"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "xgboost_model.pkl"
METRICS_PATH = MODEL_DIR / "metrics.json"
PLOT_PATH = ROOT / "static" / "actual_vs_predicted.png"

FEATURES = [
    "distance_km", "scheduled_hour", "day_of_week", "month",
    "remaining_stops", "previous_delay_min", "weather_severity",
    "congestion_index", "train_type_code"
]
TARGET = "delay_minutes"

def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"{DATA_PATH} not found. Run 'python generate_dataset.py' first."
        )

    df = pd.read_csv(DATA_PATH)
    required = FEATURES + [TARGET]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing columns: {missing}")

    df = df[required].dropna()
    X, y = df[FEATURES], df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )

    model = XGBRegressor(
        n_estimators=300,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.9,
        colsample_bytree=0.9,
        objective="reg:squarederror",
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    mae = float(mean_absolute_error(y_test, predictions))
    rmse = float(mean_squared_error(y_test, predictions) ** 0.5)
    r2 = float(r2_score(y_test, predictions))

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    (ROOT / "static").mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)

    metrics = {
        "mae_minutes": round(mae, 3),
        "rmse_minutes": round(rmse, 3),
        "r2_score": round(r2, 4),
        "test_rows": int(len(y_test)),
        "dataset_rows": int(len(df)),
        "dataset_type": "simulated starter dataset" if "SIMULATED" in (ROOT / "README.md").read_text(encoding="utf-8") else "check dataset provenance"
    }
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    plt.figure(figsize=(7, 5))
    plt.scatter(y_test, predictions, alpha=0.5)
    low = min(float(y_test.min()), float(predictions.min()))
    high = max(float(y_test.max()), float(predictions.max()))
    plt.plot([low, high], [low, high], linestyle="--")
    plt.xlabel("Actual delay (minutes)")
    plt.ylabel("Predicted delay (minutes)")
    plt.title("Actual vs Predicted Train Delay")
    plt.tight_layout()
    plt.savefig(PLOT_PATH, dpi=150)
    plt.close()

    print("XGBoost training completed.")
    print(f"MAE  : {mae:.2f} minutes")
    print(f"RMSE : {rmse:.2f} minutes")
    print(f"R2   : {r2:.4f}")
    print(f"Saved model: {MODEL_PATH}")
    print(f"Saved metrics: {METRICS_PATH}")
    print(f"Saved graph: {PLOT_PATH}")

if __name__ == "__main__":
    main()
