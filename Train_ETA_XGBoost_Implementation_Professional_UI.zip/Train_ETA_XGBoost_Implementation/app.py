"""Flask web interface for the trained train-delay model."""
from pathlib import Path
from datetime import datetime, timedelta
import json
import joblib
import pandas as pd
from flask import Flask, render_template, request

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "xgboost_model.pkl"
METRICS_PATH = ROOT / "models" / "metrics.json"

app = Flask(__name__)
FEATURES = [
    "distance_km", "scheduled_hour", "day_of_week", "month",
    "remaining_stops", "previous_delay_min", "weather_severity",
    "congestion_index", "train_type_code"
]

def load_model():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    error = None
    metrics = None

    if METRICS_PATH.exists():
        metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8"))

    if request.method == "POST":
        model = load_model()
        if model is None:
            error = "Model file not found. Run generate_dataset.py and train_model.py first."
        else:
            try:
                train_number = request.form["train_number"].strip()
                scheduled = datetime.strptime(
                    request.form["scheduled_arrival"], "%Y-%m-%dT%H:%M"
                )
                values = {
                    "distance_km": float(request.form["distance_km"]),
                    "scheduled_hour": scheduled.hour,
                    "day_of_week": scheduled.weekday(),
                    "month": scheduled.month,
                    "remaining_stops": int(request.form["remaining_stops"]),
                    "previous_delay_min": float(request.form["previous_delay_min"]),
                    "weather_severity": int(request.form["weather_severity"]),
                    "congestion_index": int(request.form["congestion_index"]),
                    "train_type_code": int(request.form["train_type_code"]),
                }

                if not train_number:
                    raise ValueError("Enter a train number.")
                if values["distance_km"] < 0 or values["remaining_stops"] < 0:
                    raise ValueError("Distance and remaining stops cannot be negative.")
                if values["previous_delay_min"] < 0:
                    raise ValueError("Previous delay cannot be negative.")
                if not 0 <= values["weather_severity"] <= 3:
                    raise ValueError("Weather severity must be between 0 and 3.")
                if not 0 <= values["congestion_index"] <= 10:
                    raise ValueError("Congestion index must be between 0 and 10.")
                if not 0 <= values["train_type_code"] <= 4:
                    raise ValueError("Select a valid train type.")

                input_df = pd.DataFrame([[values[c] for c in FEATURES]], columns=FEATURES)
                predicted_delay = max(0.0, float(model.predict(input_df)[0]))
                predicted_eta = scheduled + timedelta(minutes=predicted_delay)

                if predicted_delay <= 5:
                    status = "On Time"
                elif predicted_delay <= 30:
                    status = "Slightly Delayed"
                else:
                    status = "Highly Delayed"

                result = {
                    "train_number": train_number,
                    "delay": round(predicted_delay, 1),
                    "scheduled_eta": scheduled.strftime("%d-%m-%Y %I:%M %p"),
                    "predicted_eta": predicted_eta.strftime("%d-%m-%Y %I:%M %p"),
                    "status": status,
                }
            except (ValueError, KeyError) as exc:
                error = str(exc)

    return render_template("index.html", result=result, error=error, metrics=metrics)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
